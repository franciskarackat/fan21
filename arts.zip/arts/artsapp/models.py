from django.db import models

# Create your models here.

######################### event table #############

class event_table(models.Model):
    event_name=models.CharField(max_length=250)
    event_description=models.CharField(max_length=10000)


######################### department table #############

class add_department_table(models.Model):
    department_name=models.CharField(max_length=250)
    login_id=models.CharField(max_length=250)
    password=models.CharField(max_length=250)
    department_description=models.CharField(max_length=250)

######################### schedule table #############

class add_schedule_table(models.Model):
    event_name=models.CharField(max_length=250)
    date=models.DateField(null=True)
    start_time=models.TimeField(null=True)
    end_time=models.TimeField(null=True)
    venue = models.CharField(max_length=250)


######################### student table #############

class add_student_table(models.Model):
    ad_no=models.CharField(max_length=250)
    student_name=models.CharField(max_length=250)
    gender=models.CharField(max_length=10)
    dob=models.CharField(max_length=250)
    department=models.CharField(max_length=250)
    year=models.CharField(max_length=250)
    phone=models.CharField(max_length=10)
    email=models.CharField(max_length=250)
    address=models.CharField(max_length=250)
    student_img=models.ImageField(upload_to='student_images')


######################### result table #############

class add_result_table(models.Model):
    event_name=models.CharField(max_length=250)
    department_name=models.CharField(max_length=250)
    student_name=models.CharField(max_length=250)
    position_list=models.CharField(max_length=250)
    grade_list=models.CharField(max_length=250)
    point=models.IntegerField()

######################## points table ################

class score_table(models.Model):
    bba_score=models.IntegerField(null=True)
    ba_score=models.IntegerField(null=True)
    bca_score=models.IntegerField(null=True)
    bsw_score=models.IntegerField(null=True)
    bcom_fin_score=models.IntegerField(null=True)
    bcom_cop_score=models.IntegerField(null=True)
    bcom_com_score=models.IntegerField(null=True)
    bsc_psy_score=models.IntegerField(null=True)
    bsc_maths_score=models.IntegerField(null=True)

######################## Add live streaming ################

class add_live_table(models.Model):
    youtube_url=models.CharField(max_length=250)



######################### gallery table #############

class add_gallery_table(models.Model):
    title=models.CharField(max_length=250)
    upload_img=models.ImageField(upload_to='gallery_img')



######################### participants table #############

class add_participants_form_table(models.Model):
    admission_no=models.CharField(max_length=250)
    participant_name=models.CharField(max_length=250)
    participant_gender=models.CharField(max_length=250)
    participant_dob=models.CharField(max_length=250)
    participant_department=models.CharField(max_length=250)
    participant_year=models.CharField(max_length=250)
    event_selected=models.CharField(max_length=250)

######################### feedback table #############

class add_feedback_table(models.Model):
    name=models.CharField(max_length=250)
    email=models.CharField(max_length=250)
    message=models.CharField(max_length=250)

######################### Appeal table #############

class add_appeal_table(models.Model):
    department=models.CharField(max_length=250)
    event_name=models.CharField(max_length=250)
    appeal=models.CharField(max_length=250)


######################### Appeal table #############

class add_notification_table(models.Model):
    message=models.CharField(max_length=250)
    date=models.DateField(null=True)
    remark=models.CharField(max_length=250)




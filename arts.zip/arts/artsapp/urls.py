"""arts URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .import views
from django.conf.urls import (handler404)

handler404='artsapp.views.handler404'
urlpatterns = [
    path('home', views.homepage, name="home"),
    path('dashboard', views.dashboard, name="dashboard"),
    path('students',views.students, name="students"),
    path('add-student', views.add_student, name="add-student"),
    path('edit-student<int:student_id>', views.edit_student, name="edit-stud"),
    path('event', views.event, name="event"),
    path('add-event', views.add_event, name="add-event"),
    path('add-live', views.add_live, name="add-live"),
    path('edit-event<int:event_id>', views.edit_event, name="edit-event"),
    path('department', views.department, name="department"),
    path('add-department', views.add_department, name="add-department"),
    path('edit-department<int:department_id>', views.edit_department, name="edit-department"),
    path('result', views.result, name="result"),
    path('add-result', views.add_result, name="add-result"),
    path('edit-result<int:result_id>', views.edit_result, name="edit-result"),
    path('schedule-event', views.schedule_event, name="schedule-event"),
    path('schedule-edit<int:schedule_id>', views.schedule_edit, name="schedule-edit"),
    path('schedule-list', views.schedule_list, name="schedule-list"),
    path('profile', views.profile, name="profile"),
    path('zzz', views.zzz, name="zzz"),
    path('gallery', views.gallery, name="gallery"),
    path('live', views.live, name="live"),
    path('resultindex', views.resultindex, name="results"),
    path('scheduleindex', views.scheduleindex, name="schedule"),
    path('rep-dashboard', views.rep_dashboard, name="rep-dashboard"),
    path('login', views.login, name="login"),
    path('downloads', views.downloads, name="downloads"),
    path('add-gallery', views.add_gallery, name="add-gallery"),
    path('list-gallery', views.list_gallery, name="list-gallery"),
    path('add-participants', views.add_participants, name="add-participants"),
    path('add-participants-form', views.add_participants_form, name="add-participants-form"),
    path('add-appeal', views.add_appeal, name="add-appeal"),
    path('appeal', views.appeal, name="appeal"),
    path('admin-student', views.admin_students, name="admin-student"),
    path('feedback', views.feedback, name="feedback"),
    path('add-notification', views.add_notification, name="add-notification"),
    path('notification', views.notification, name="notification"),
]

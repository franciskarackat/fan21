from django.shortcuts import render
from .forms import *
from .models import *
from django.contrib import messages

# Create your views here.

########### user homepage ###########
def homepage(request):
    obj=event_table.objects.all()
    if request.method == "POST":
        form = add_feedback_form(request.POST)

        if form.is_valid():
            form.save()
        else:
            form = add_feedback_form()
    return render(request,'index.html')


################ add department ############

def add_department(request):
    obj = add_notification_table.objects.all()
    if request.method == "POST":
        form = add_department_form(request.POST)

        if form.is_valid():
            form.save()
        else:
            form = add_department_form()
    return render(request,'add-department.html',{"notification_details":obj})

#############   add event  ##############
def add_event(request):
    obj = add_notification_table.objects.all()


    if request.method == "POST":
        form=add_event_form(request.POST)

        if form.is_valid():
            form.save()
        else:
            form = add_event_form()

    return render(request,'add-event.html',{"notification_details":obj})



#############  Admin  dashboard  ##############
def dashboard(request):
    obj = add_notification_table.objects.all()

    if request.method == "POST":
        req_id = request.POST.get("id")
        obj_delete = add_notification_table.objects.get(id=req_id)
        obj_delete.delete()

    return render(request,'dashboard.html',{"notification_details":obj})


#############   students  ##############
def students(request):
    obj=add_student_table.objects.all()

    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=add_student_table.objects.get(id=req_id)
        obj_delete.delete()

    return render(request,'students.html',{"student_details":obj})




#############   Add students  ##############
def add_student(request):
    obj=add_department_table.objects.all()
    if request.method == "POST":
        form = add_student_form(request.POST,request.FILES)

        if form.is_valid():
            form.save()
        else:
            form = add_student_form()

    return render(request,'add-student.html',{"dept_details":obj})



#############   Add result  ##############
def add_result(request):
    obj1 = add_department_table.objects.all()
    obj2 = event_table.objects.all()
    obj3 = score_table.objects.all()
    point_ba=0
    point_bba=0
    point_bca=0
    point_bsw=0
    point_bcom_com=0
    point_bcom_fin=0
    point_bcom_cop=0
    point_bsc_maths=0
    point_psy=0
    



    context={
        "result_details": obj1,
        "event_details": obj2
    }
    if request.method == "POST":

        get_grade = request.POST.get("grade_list")
        get_position = request.POST.get("position_list")
        get_name = request.POST.get("event_name")
        get_dept_name = request.POST.get("department_name")
        get_stud_name = request.POST.get("student_name")
        get_points = request.POST.get("point")
        #print(get_dept_name)
        if get_dept_name == "BA":
            #print("@@@@@@@@@@@@@")
            
            for x in obj3:   
                point_ba=x.ba_score+int(get_points)
                point_bba=x.bba_score+0
                point_bca=x.bca_score+0
                point_bsw=x.bsw_score+0
                point_bcom_com=x.bcom_com_score+0
                point_bcom_cop=x.bcom_cop_score+0
                point_bcom_fin=x.bcom_fin_score+0
                point_bsc_maths=x.bsc_maths_score+0
                point_psy=x.bsc_psy_score+0

        elif get_dept_name == "BBA":

            for x in obj3:   
                point_ba=x.ba_score+0
                point_bba=x.bba_score+int(get_points)
                point_bca=x.bca_score+0
                point_bsw=x.bsw_score+0
                point_bcom_com = x.bcom_com_score + 0
                point_bcom_cop = x.bcom_cop_score + 0
                point_bcom_fin = x.bcom_fin_score + 0
                point_bsc_maths = x.bsc_maths_score + 0
                point_psy = x.bsc_psy_score + 0

        elif get_dept_name == "BCA":
    
            for x in obj3:   
                point_ba=x.ba_score+0
                point_bba=x.bba_score+0
                point_bca=x.bca_score+int(get_points)
                point_bsw=x.bsw_score+0
                point_bcom_com = x.bcom_com_score + 0
                point_bcom_cop = x.bcom_cop_score + 0
                point_bcom_fin = x.bcom_fin_score + 0
                point_bsc_maths = x.bsc_maths_score + 0
                point_psy = x.bsc_psy_score + 0
        
        elif get_dept_name == "BSW":
        
            for x in obj3:   
                point_ba=x.ba_score+0
                point_bba=x.bba_score+0
                point_bca=x.bca_score+0
                point_bsw=x.bsw_score+int(get_points)
                point_bcom_com = x.bcom_com_score + 0
                point_bcom_cop = x.bcom_cop_score + 0
                point_bcom_fin = x.bcom_fin_score + 0
                point_bsc_maths = x.bsc_maths_score + 0
                point_psy = x.bsc_psy_score + 0

        elif get_dept_name == "BCOM COM":
            for x in obj3:
                point_ba=x.ba_score+0
                point_bba=x.bba_score+0
                point_bca=x.bca_score+0
                point_bsw=x.bsw_score+0
                point_bcom_com = x.bcom_com_score + int(get_points)
                point_bcom_cop = x.bcom_cop_score + 0
                point_bcom_fin = x.bcom_fin_score + 0
                point_bsc_maths = x.bsc_maths_score + 0
                point_psy = x.bsc_psy_score + 0
        elif get_dept_name == "BCOM COP":
            for x in obj3:
                point_ba=x.ba_score+0
                point_bba=x.bba_score+0
                point_bca=x.bca_score+0
                point_bsw=x.bsw_score+0
                point_bcom_com = x.bcom_com_score + 0
                point_bcom_cop = x.bcom_cop_score + int(get_points)
                point_bcom_fin = x.bcom_fin_score + 0
                point_bsc_maths = x.bsc_maths_score + 0
                point_psy = x.bsc_psy_score + 0
        elif get_dept_name == "BCOM FIN":
            for x in obj3:
                point_ba=x.ba_score+0
                point_bba=x.bba_score+0
                point_bca=x.bca_score+0
                point_bsw=x.bsw_score+0
                point_bcom_com = x.bcom_com_score + 0
                point_bcom_cop = x.bcom_cop_score + 0
                point_bcom_fin = x.bcom_fin_score + int(get_points)
                point_bsc_maths = x.bsc_maths_score + 0
                point_psy = x.bsc_psy_score + 0
        elif get_dept_name == "BSC MATHS":
            for x in obj3:
                point_ba=x.ba_score+0
                point_bba=x.bba_score+0
                point_bca=x.bca_score+0
                point_bsw=x.bsw_score+0
                point_bcom_com = x.bcom_com_score + 0
                point_bcom_cop = x.bcom_cop_score + 0
                point_bcom_fin = x.bcom_fin_score + 0
                point_bsc_maths = x.bsc_maths_score + int(get_points)
                point_psy = x.bsc_psy_score + 0
        else:

            for x in obj3:   
                point_ba=x.ba_score+0
                point_bba=x.bba_score+0
                point_bca=x.bca_score+0
                point_bsw=x.bsw_score+0
                point_bcom_com = x.bcom_com_score + 0
                point_bcom_cop = x.bcom_cop_score + 0
                point_bcom_fin = x.bcom_fin_score + 0
                point_bsc_maths = x.bsc_maths_score + 0
                point_psy = x.bsc_psy_score + int(get_points)
            

            
        
        
        score_table(ba_score=point_ba,bba_score=point_bba,bca_score=point_bca,bsw_score=point_bsw,bcom_com_score=point_bcom_com,bcom_fin_score=point_bcom_fin,bcom_cop_score=point_bcom_cop,bsc_maths_score=point_bsc_maths,bsc_psy_score=point_psy).save()
            
            




        add_result_table(event_name=get_name, department_name=get_dept_name, student_name=get_stud_name, position_list=get_position, grade_list=get_grade, point=get_points).save()


    return render(request, 'add-result.html', context)



#############   edit student  ##############
def edit_student(request,student_id):
    obj=add_student_table.objects.get(id=student_id)

    if request.method == "POST":
        form = edit_student_form(request.POST,instance=obj)

        if form.is_valid():
            form.save()
        else:
            form = edit_student_form()

    return render(request,'edit-student.html',{"student_details":obj})


#############   edit department  ##############
def edit_department(request,department_id):
    obj=add_department_table.objects.get(id=department_id)

    if request.method == "POST":
        form = add_department_form(request.POST,instance=obj)

        if form.is_valid():
            form.save()
        else:
            form = add_department_form()

    return render(request,'edit-department.html',{"department_details":obj})


#############   edit event ##############
def edit_event(request,event_id):

    obj=event_table.objects.get(id=event_id)

    if request.method == "POST":
        form = add_event_form(request.POST,instance=obj)

        if form.is_valid():
            form.save()
        else:
            form = add_event_form()

    return render(request,'edit-event.html',{"event_details":obj})




#############   edit result ##############
def edit_result(request,result_id):
    obj = add_result_table.objects.get(id=result_id)

    if request.method == "POST":
        form = add_result_form(request.POST, instance=obj)

        if form.is_valid():
            form.save()
        else:
            form = add_result_form()

    return render(request, 'edit-result.html', {"event_result": obj})




#############   edit schedule ##############
def schedule_edit(request,schedule_id):
    obj=add_schedule_table.objects.get(id=schedule_id)

    if request.method == "POST":
        form = add_schedule_form(request.POST,instance=obj)

        if form.is_valid():
            form.save()
        else:
            form = add_schedule_form()

    return render(request,'edit-schedule.html',{"schedule_details":obj})






#############   event ##############
def event(request):
    obj=event_table.objects.all()

    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=event_table.objects.get(id=req_id)
        obj_delete.delete()

    return render(request,'event.html',{"event_details":obj})

#############   error 404 ##############
def handler404(request, exception):
    return render(request,'error-404.html',locals())

#############   login ##############
def login(request):

    return render(request,'login.html')

#############   downloads ##############
def downloads(request):

    return render(request,'downloads.html')

#############   profile ##############
def profile(request):

    return render(request,'profile.html')

#############   result ##############
def result(request):
    obj=add_result_table.objects.all()

    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=add_result_table.objects.get(id=req_id)
        obj_delete.delete()

    return render(request,'result.html',{"result_details":obj})


#############   department  ##############
def department(request):
    obj=add_department_table.objects.all()

    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=add_department_table.objects.get(id=req_id)
        obj_delete.delete()



    return render(request,'departments.html',{"dept_details":obj})

#############   schedule ##############
def schedule_event(request):
    obj=event_table.objects.all()
    if request.method == "POST":
        form = add_schedule_form(request.POST)

        if form.is_valid():
            form.save()
        else:
            form = add_schedule_form()

    return render(request,'schedule-event.html',{"event_details":obj})


#############   list schedule ##############
def schedule_list(request):
    obj=add_schedule_table.objects.all()

    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=add_schedule_table.objects.get(id=req_id)
        obj_delete.delete()

    return render(request,'schedule-list.html',{"schedule_details":obj})


#############   zzzzzz  ##############
def zzz(request):
    obj=add_result_table.objects.all()

    return render(request,'zzz.html',{"result_details":obj})


#############   gallery ##############
def gallery(request):
    obj=add_gallery_table.objects.all()

    return render(request,'gallery.html',{"image_details":obj})

#############   live ##############
def live(request):
    obj=add_live_table.objects.get()


    return render(request,'live.html',{"live_details":obj})

#############   Result Index ##############
def resultindex(request):
    obj1=add_result_table.objects.all()
    obj2=score_table.objects.all().last()



    context={
        "result_details":obj1,
        "score_details":obj2
    }
    return render(request,'resultindex.html',context)


#############   Schedule Index ##############
def scheduleindex(request):
    obj=add_schedule_table.objects.all()

    return render(request,'scheduleindex.html',{"schedule_index":obj})


#############   add live ##############
def add_live(request):
    if request.method == "POST":
        obj=add_live_table.objects.all()
        obj.delete()
        form = add_live_form(request.POST)

        if form.is_valid():
            form.save()
        else:
            form = add_live_form()

    return render(request,'add-live.html')


#############   o ##############
def o(request):

    return render(request,'o-index.html')



#############   rep dashboard ##############
def rep_dashboard(request):

    return render(request,'rep-dashboard.html')

#############   Add Gallery ##############
def add_gallery(request):
    if request.method == "POST":

        form = add_gallery_form(request.POST,request.FILES)

        if form.is_valid():
            form.save()
        else:
            form = add_gallery_form()
    return render(request,'add-gallery.html')


#############   list gallery ##############
def list_gallery(request):
    obj=add_gallery_table.objects.all()
    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=add_gallery_table.objects.get(id=req_id)
        obj_delete.delete()

    return render(request,'list-gallery.html',{"gallery_details":obj})




#############   add participants ##############
def add_participants(request):
    if request.method == "POST" and "search_btn" in request.POST:
        get_ad_no=request.POST.get("ad_no")
        if add_student_table.objects.filter(ad_no=get_ad_no).exists():

            obj_stud=add_student_table.objects.get(ad_no=get_ad_no)
            obj_event=event_table.objects.all()
            context={
                'student_details':obj_stud,
                'event_details':obj_event
            }
            if request.method == "POST" and "add_btn" in request.POST:

                get_number=request.POST.get("admission_no")
                get_name=request.POST.get("participant_name")
                print("#################################")

                print(get_number)
                print(get_name)

                print("#################################")

                form = add_participants_form(request.POST)

                if form.is_valid():
                    form.save()
                else:
                    form = add_participants_form()
            return render(request,'add-participants-form.html',context)
        else:
            messages.error(request,"No student details found !!")



    return render(request,'add-participants.html')


#############   Add appeal  ##############
def add_appeal(request):
    obj=event_table.objects.all()
    obj2=add_department_table.objects.all()
    if request.method == "POST":
        form=add_appeal_form(request.POST)

        if form.is_valid():
            form.save()
        else:
            form = add_appeal_form()
    return render(request,'add-appeal.html',{"event_details":obj,"dept_details":obj2})


#############   List appeal ##############
def appeal(request):
    obj=add_appeal_table.objects.all()
    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=add_appeal_table.objects.get(id=req_id)
        obj_delete.delete()

    return render(request,'appeal.html',{"appeal_details":obj})


#############   Admin Student list ##############
def admin_students(request):
    obj=add_student_table.objects.all()

    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=add_student_table.objects.get(id=req_id)
        obj_delete.delete()

    return render(request,'admin-students.html',{"student_details":obj})

#############   Feedback list ##############
def feedback(request):
    obj=add_feedback_table.objects.all()

    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=add_feedback_table.objects.get(id=req_id)
        obj_delete.delete()

    return render(request,'feedback.html',{"feedback_details":obj})

#############   Add Notification ##############
def add_notification(request):
    if request.method == "POST":
        form = add_notification_form(request.POST)

        if form.is_valid():
            form.save()
        else:
            form = add_notification_form()


    return render(request,'add-notification.html')


#############   List Notification ##############
def notification(request):
    obj=add_notification_table.objects.all()

    if request.method == "POST":
        req_id=request.POST.get("id")
        obj_delete=add_notification_table.objects.get(id=req_id)
        obj_delete.delete()
    return render(request,'notification.html',{"notification_details":obj})

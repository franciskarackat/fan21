from django import forms
from .models import *





########################## event add form #############################

class add_event_form(forms.ModelForm):
    class Meta:
        model=event_table
        fields=['event_name','event_description']

##########################  add department #############################

class add_department_form(forms.ModelForm):
     class Meta:
        model = add_department_table
        fields = ['department_name', 'login_id','password','department_description']


##########################  add schedule #############################

class add_schedule_form(forms.ModelForm):
     class Meta:
        model = add_schedule_table
        fields = ['event_name', 'date','start_time','end_time','venue']


##########################  add student #############################

class add_student_form(forms.ModelForm):
     class Meta:
        model = add_student_table
        fields = ['ad_no','student_name','gender','dob','department','year','phone','email','address','student_img']


##########################  edit student #############################

class edit_student_form(forms.ModelForm):
     class Meta:
        model = add_student_table
        fields = ['ad_no','student_name','gender','dob','department','year','phone','email']


##########################  add result #############################

class add_result_form(forms.ModelForm):
     class Meta:
        model = add_result_table
        fields = ['event_name', 'department_name','student_name','position_list','grade_list','point']


##########################  add live #############################

class add_live_form(forms.ModelForm):
     class Meta:
        model = add_live_table
        fields = ['youtube_url']


##########################  add gallery #############################

class add_gallery_form(forms.ModelForm):
     class Meta:
        model = add_gallery_table
        fields = ['title','upload_img']

##########################  add participants form #############################

class add_participants_form(forms.ModelForm):
     class Meta:
        model = add_participants_form_table
        fields = ['admission_no','participant_name','participant_gender','participant_dob','participant_department', 'participant_year' ,'event_selected']


##########################  add Feedback Form #############################

class add_feedback_form(forms.ModelForm):
     class Meta:
        model = add_feedback_table
        fields = ['name','email','message']


##########################  add appeal Form #############################

class add_appeal_form(forms.ModelForm):
     class Meta:
        model = add_appeal_table
        fields = ['department','event_name','appeal']


##########################  add Notification Form #############################

class add_notification_form(forms.ModelForm):
     class Meta:
        model = add_notification_table
        fields = ['message','date','remark']

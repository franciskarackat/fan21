from django.apps import AppConfig


class ArtsappConfig(AppConfig):
    name = 'artsapp'
